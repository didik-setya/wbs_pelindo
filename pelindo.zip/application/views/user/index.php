<div class="row mt-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4>Dashboard</h4>
            </div>
        </div>
    </div>
</div>